package com.example.ejercicioad;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HelloController implements Initializable {

    @FXML
    private Button siguienteButton;
    @FXML
    private Button precioButton;
    @FXML
    private Label precioLabel;
    @FXML
    private Label posicionText;
    @FXML
    private Label equipoText;
    @FXML
    private Label nombreText;
    @FXML
    private Label añoText;
    @FXML
    private Label idText;

    Integer position;

    ApoyoXML datos = new ApoyoXML();


    @Override
    public void initialize(URL url, ResourceBundle rb) {

        position = 0;


        try {
            datos.LeerXML("Jugador.xml");

            Jugador jugador = new Jugador();
            jugador=datos.Read(0);
            idText.setText(String.valueOf(jugador.getID()));
            nombreText.setText(jugador.getNombre());
            equipoText.setText(jugador.getNombre());
            añoText.setText(jugador.getAnyo());
            posicionText.setText(jugador.getPosicion());

        } catch (SAXException ex) {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(HelloController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @FXML
    private void handleButtonActionNext(ActionEvent event) {
        position++;

        if(position==datos.registros()){
            idText.setText("");
            nombreText.setText("");
            equipoText.setText("");
            añoText.setText("");
            posicionText.setText("");
        }
        else{
            datos.Read(position);
        }
    }

}

